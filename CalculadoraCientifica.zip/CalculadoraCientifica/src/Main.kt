// Main.kt
fun main() {
    try {
        val interfaz = InterfazCalculadora()
        interfaz.iniciar()
    } catch (e: Exception) {
        println("Error crítico: ${e.message}")
        e.printStackTrace()
    }
}
