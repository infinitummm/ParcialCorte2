
open class CalculadoraException(message: String) : Exception(message)

class DivisionPorCeroException : CalculadoraException("Error: División por cero no permitida")

class ValorInvalidoException(mensaje: String) : CalculadoraException("Valor inválido: $mensaje")

class ExpresionInvalidaException(mensaje: String) : CalculadoraException("Expresión inválida: $mensaje")
