
import kotlin.math.*

class ExpressionParser(private val calculadora: CalculadoraCientifica) {
    private var posicion = 0
    private lateinit var expresion: String

    fun evaluar(expr: String): Double {
        expresion = expr.replace(" ", "")
        posicion = 0
        val resultado = evaluarExpresion()
        if (posicion < expresion.length) {
            throw ExpresionInvalidaException("Caracteres inesperados al final de la expresión")
        }
        return resultado
    }

    private fun evaluarExpresion(): Double {
        var resultado = evaluarTermino()

        while (posicion < expresion.length) {
            val operador = expresion[posicion]
            if (operador == '+' || operador == '-') {
                posicion++
                val termino = evaluarTermino()
                resultado = if (operador == '+') {
                    calculadora.sumar(resultado, termino)
                } else {
                    calculadora.restar(resultado, termino)
                }
            } else {
                break
            }
        }
        return resultado
    }

    private fun evaluarTermino(): Double {
        var resultado = evaluarFactor()

        while (posicion < expresion.length) {
            val operador = expresion[posicion]
            if (operador == '*' || operador == '/') {
                posicion++
                val factor = evaluarFactor()
                resultado = if (operador == '*') {
                    calculadora.multiplicar(resultado, factor)
                } else {
                    calculadora.dividir(resultado, factor)
                }
            } else {
                break
            }
        }
        return resultado
    }

    private fun evaluarFactor(): Double {
        if (posicion >= expresion.length) {
            throw ExpresionInvalidaException("Expresión incompleta")
        }

        if (expresion[posicion] == '-') {
            posicion++
            return -evaluarFactor()
        }

        if (expresion[posicion] == '+') {
            posicion++
            return evaluarFactor()
        }

        if (expresion[posicion] == '(') {
            posicion++
            val resultado = evaluarExpresion()
            if (posicion >= expresion.length || expresion[posicion] != ')') {
                throw ExpresionInvalidaException("Paréntesis no balanceados")
            }
            posicion++
            return resultado
        }

        return evaluarNumeroOFuncion()
    }

    private fun evaluarNumeroOFuncion(): Double {
        if (posicion < expresion.length && expresion[posicion].isLetter()) {
            val funcion = leerFuncion()
            return evaluarFuncionMatematica(funcion)
        }
        return leerNumero()
    }

    private fun leerFuncion(): String {
        val inicio = posicion
        while (posicion < expresion.length && expresion[posicion].isLetter()) {
            posicion++
        }
        return expresion.substring(inicio, posicion)
    }

    private fun leerNumero(): Double {
        val inicio = posicion

        while (posicion < expresion.length && expresion[posicion].isDigit()) {
            posicion++
        }

        if (posicion < expresion.length && expresion[posicion] == '.') {
            posicion++
            while (posicion < expresion.length && expresion[posicion].isDigit()) {
                posicion++
            }
        }

        if (inicio == posicion) {
            throw ExpresionInvalidaException("Se esperaba un número en posición $posicion")
        }

        return expresion.substring(inicio, posicion).toDouble()
    }

    private fun evaluarFuncionMatematica(funcion: String): Double {
        if (posicion >= expresion.length || expresion[posicion] != '(') {
            throw ExpresionInvalidaException("Se esperaba '(' después de la función $funcion")
        }
        posicion++

        val argumento = evaluarExpresion()

        if (posicion >= expresion.length || expresion[posicion] != ')') {
            throw ExpresionInvalidaException("Se esperaba ')' para la función $funcion")
        }
        posicion++

        return when (funcion.lowercase()) {
            "sin", "sen" -> calculadora.seno(argumento)
            "cos" -> calculadora.coseno(argumento)
            "tan" -> calculadora.tangente(argumento)
            "sqrt", "raiz" -> calculadora.raizCuadrada(argumento)
            "log" -> calculadora.logaritmoBase10(argumento)
            "ln" -> calculadora.logaritmoNatural(argumento)
            "exp" -> calculadora.exponencial(argumento)
            "abs" -> calculadora.valorAbsoluto(argumento)
            else -> throw ExpresionInvalidaException("Función desconocida: $funcion")
        }
    }
}
