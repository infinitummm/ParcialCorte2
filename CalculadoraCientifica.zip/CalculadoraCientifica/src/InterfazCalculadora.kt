
class InterfazCalculadora {
    private val calc = CalculadoraCientifica()

    fun iniciar() {
        println("""
        ╔════════════════════════════════════════╗
        ║       CALCULADORA CIENTÍFICA KOTLIN    ║
        ║         Programación Orientada a       ║
        ║             Objetos (POO)              ║
        ╚════════════════════════════════════════╝
        """.trimIndent())

        mostrarAyuda()

        while (true) {
            try {
                print("\n Calculadora> ")
                val entrada = readLine()?.trim() ?: continue

                when {
                    entrada.isEmpty() -> continue
                    entrada == "ayuda" || entrada == "help" -> mostrarAyuda()
                    entrada == "salir" || entrada == "exit" -> break
                    entrada == "historial" -> calc.mostrarHistorial()
                    entrada == "limpiar" -> calc.limpiarHistorial()
                    entrada.startsWith("precision ") -> cambiarPrecision(entrada)
                    entrada.startsWith("modo ") -> cambiarModoAngulos(entrada)
                    entrada == "memoria" || entrada == "mr" -> mostrarResultado(calc.memoriaRecuperar())
                    entrada.startsWith("ms ") -> guardarEnMemoria(entrada)
                    entrada.startsWith("m+ ") -> sumarAMemoria(entrada)
                    entrada.startsWith("m- ") -> restarAMemoria(entrada)
                    entrada == "mc" -> calc.memoriaLimpiar()
                    entrada == "estado" -> mostrarEstado()
                    else -> evaluarExpresion(entrada)
                }
            } catch (e: CalculadoraException) {
                println(" ${e.message}")
            } catch (e: Exception) {
                println(" Error inesperado: ${e.message}")
            }
        }

        println("\n chao xd")
    }

    private fun mostrarAyuda() {
        println("""
        ╔═══════════════════════════════════════════════════════════════════╗
        ║                           COMANDOS                                ║
        ╠═══════════════════════════════════════════════════════════════════╣
        ║ • Expresiones: 2 + 3 * 4, sqrt(16), sin(30), log(100)             ║
        ║ • Memoria: ms <valor>, mr, m+ <valor>, m- <valor>, mc             ║
        ║ • Configuración: precision <n>, modo <radianes|grados>            ║
        ║ • Utilidades: historial, limpiar, estado, ayuda, salir            ║
        ╚═══════════════════════════════════════════════════════════════════╝
        """.trimIndent())
    }

    private fun evaluarExpresion(expresion: String) {
        val resultado = calc.evaluarExpresion(expresion)
        mostrarResultado(resultado)
    }

    private fun mostrarResultado(resultado: Double) {
        val formatado = calc.formatearResultado(resultado)
        println(" Resultado: $formatado")
    }

    private fun cambiarPrecision(comando: String) {
        try {
            val precision = comando.split(" ")[1].toInt()
            calc.precision = precision
            println(" Precisión establecida en $precision dígitos")
        } catch (e: Exception) {
            println(" Formato inválido. Use: precision <número>")
        }
    }

    private fun cambiarModoAngulos(comando: String) {
        val modo = comando.split(" ")[1]
        calc.modoAngulos = modo
        println(" Modo de ángulos: ${calc.modoAngulos}")
    }

    private fun guardarEnMemoria(comando: String) {
        try {
            val valor = comando.split(" ")[1].toDouble()
            calc.memoriaGuardar(valor)
        } catch (e: Exception) {
            println(" Formato inválido. Use: ms <número>")
        }
    }

    private fun sumarAMemoria(comando: String) {
        try {
            val valor = comando.split(" ")[1].toDouble()
            calc.memoriaSumar(valor)
        } catch (e: Exception) {
            println(" Formato inválido. Use: m+ <número>")
        }
    }

    private fun restarAMemoria(comando: String) {
        try {
            val valor = comando.split(" ")[1].toDouble()
            calc.memoriaRestar(valor)
        } catch (e: Exception) {
            println(" Formato inválido. Use: m- <número>")
        }
    }

    private fun mostrarEstado() {
        println("""
        ╔═══════════════════════════════════════╗
        ║               ESTADO                  ║
        ╠═══════════════════════════════════════╣
        ║ Precisión: ${calc.precision} dígitos                 ║
        ║ Modo ángulos: ${calc.modoAngulos}                ║
        ║ Memoria: ${calc.formatearResultado(calc.memoriaRecuperar())}                   ║
        ╚═══════════════════════════════════════╝
        """.trimIndent())
    }
}
