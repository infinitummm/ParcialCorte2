
import kotlin.math.*
private operator fun String.times(n: Int) = repeat(n)

open class Calculadora {


    private var memoria: Double = 0.0
    private val historial: MutableList<String> = mutableListOf()


    var precision: Int = 10
        set(value) {
            field = if (value > 0) value else 10
        }




    open fun sumar(a: Int, b: Int): Int = a + b
    open fun sumar(a: Double, b: Double): Double {
        val resultado = a + b
        registrarOperacion("$a + $b = $resultado")
        return resultado
    }

    open fun restar(a: Int, b: Int): Int = a - b
    open fun restar(a: Double, b: Double): Double {
        val resultado = a - b
        registrarOperacion("$a - $b = $resultado")
        return resultado
    }

    open fun multiplicar(a: Int, b: Int): Int = a * b
    open fun multiplicar(a: Double, b: Double): Double {
        val resultado = a * b
        registrarOperacion("$a * $b = $resultado")
        return resultado
    }


    open fun dividir(a: Int, b: Int): Double {
        if (b == 0) throw DivisionPorCeroException()
        return a.toDouble() / b.toDouble()
    }

    open fun dividir(a: Double, b: Double): Double {
        if (abs(b) < 1e-10) throw DivisionPorCeroException()
        val resultado = a / b
        registrarOperacion("$a / $b = $resultado")
        return resultado
    }


    fun memoriaGuardar(valor: Double) {
        memoria = valor
        registrarOperacion("Memoria guardada: $valor")
        println(" Valor $valor guardado en memoria")
    }

    fun memoriaRecuperar(): Double {
        registrarOperacion("Memoria recuperada: $memoria")
        println(" Valor recuperado de memoria: $memoria")
        return memoria
    }

    fun memoriaSumar(valor: Double) {
        memoria += valor
        registrarOperacion("M+ $valor, Memoria actual: $memoria")
        println(" Memoria + $valor = $memoria")
    }

    fun memoriaRestar(valor: Double) {
        memoria -= valor
        registrarOperacion("M- $valor, Memoria actual: $memoria")
        println(" Memoria - $valor = $memoria")
    }

    fun memoriaLimpiar() {
        memoria = 0.0
        registrarOperacion("Memoria limpiada")
        println("🗑 Memoria limpiada")
    }


    protected fun registrarOperacion(operacion: String) {
        historial.add("${java.time.LocalDateTime.now()}: $operacion")
        if (historial.size > 100) {
            historial.removeFirst()
        }
    }

    fun mostrarHistorial() {
        println("\n HISTORIAL DE OPERACIONES:")
        println("=" * 40)
        if (historial.isEmpty()) {
            println("No hay operaciones en el historial")
        } else {
            historial.takeLast(10).forEach { println(it) }
        }
    }

    fun limpiarHistorial() {
        historial.clear()
        println(" Historial limpiado")
    }


    open fun formatearResultado(resultado: Double): String {
        return if (resultado == floor(resultado)) {
            resultado.toInt().toString()
        } else {
            "%.${precision}f".format(resultado).trimEnd('0').trimEnd('.')
        }
    }
}
