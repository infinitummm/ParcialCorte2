
import kotlin.math.*

class CalculadoraCientifica : Calculadora() {


    private var esRadianes: Boolean = true


    var modoAngulos: String
        get() = if (esRadianes) "Radianes" else "Grados"
        set(value) {
            esRadianes = value.lowercase() == "radianes" || value.lowercase() == "rad"
        }


    override fun formatearResultado(resultado: Double): String {
        return when {
            abs(resultado) >= 1e6 || abs(resultado) <= 1e-6 && resultado != 0.0 ->
                "%.${precision}e".format(resultado)
            else -> super.formatearResultado(resultado)
        }
    }


    fun seno(angulo: Double): Double {
        val anguloRad = if (esRadianes) angulo else Math.toRadians(angulo)
        val resultado = sin(anguloRad)
        registrarOperacion("sin($angulo${if (esRadianes) " rad" else "°"}) = $resultado")
        return resultado
    }

    fun coseno(angulo: Double): Double {
        val anguloRad = if (esRadianes) angulo else Math.toRadians(angulo)
        val resultado = cos(anguloRad)
        registrarOperacion("cos($angulo${if (esRadianes) " rad" else "°"}) = $resultado")
        return resultado
    }

    fun tangente(angulo: Double): Double {
        val anguloRad = if (esRadianes) angulo else Math.toRadians(angulo)
        val cosValue = cos(anguloRad)
        if (abs(cosValue) < 1e-10) {
            throw ValorInvalidoException("Tangente indefinida para $angulo${if (esRadianes) " radianes" else " grados"}")
        }
        val resultado = tan(anguloRad)
        registrarOperacion("tan($angulo${if (esRadianes) " rad" else "°"}) = $resultado")
        return resultado
    }


    fun potencia(base: Double, exponente: Double): Double {
        try {
            val resultado = base.pow(exponente)
            if (resultado.isNaN() || resultado.isInfinite()) {
                throw ValorInvalidoException("Resultado indefinido para $base^$exponente")
            }
            registrarOperacion("$base^$exponente = $resultado")
            return resultado
        } catch (e: Exception) {
            throw ValorInvalidoException("Error en cálculo de potencia: ${e.message}")
        }
    }

    fun raizCuadrada(valor: Double): Double {
        if (valor < 0) {
            throw ValorInvalidoException("No se puede calcular raíz cuadrada de número negativo")
        }
        val resultado = sqrt(valor)
        registrarOperacion("√$valor = $resultado")
        return resultado
    }


    fun logaritmoBase10(valor: Double): Double {
        if (valor <= 0) {
            throw ValorInvalidoException("El logaritmo solo acepta valores positivos")
        }
        val resultado = log10(valor)
        registrarOperacion("log₁₀($valor) = $resultado")
        return resultado
    }

    fun logaritmoNatural(valor: Double): Double {
        if (valor <= 0) {
            throw ValorInvalidoException("El logaritmo natural solo acepta valores positivos")
        }
        val resultado = ln(valor)
        registrarOperacion("ln($valor) = $resultado")
        return resultado
    }


    fun exponencial(exponente: Double): Double {
        val resultado = exp(exponente)
        if (resultado.isInfinite()) {
            throw ValorInvalidoException("Resultado demasiado grande para exponencial")
        }
        registrarOperacion("e^$exponente = $resultado")
        return resultado
    }


    fun gradosARadianes(grados: Double): Double {
        val resultado = Math.toRadians(grados)
        registrarOperacion("$grados° = $resultado rad")
        return resultado
    }

    fun radianesAGrados(radianes: Double): Double {
        val resultado = Math.toDegrees(radianes)
        registrarOperacion("$radianes rad = $resultado°")
        return resultado
    }


    fun factorial(n: Int): Double {
        if (n < 0) {
            throw ValorInvalidoException("El factorial no está definido para números negativos")
        }
        if (n > 170) {
            throw ValorInvalidoException("Factorial demasiado grande (máximo 170)")
        }

        var resultado = 1.0
        for (i in 2..n) {
            resultado *= i
        }
        registrarOperacion("$n! = $resultado")
        return resultado
    }

    fun valorAbsoluto(valor: Double): Double {
        val resultado = abs(valor)
        registrarOperacion("|$valor| = $resultado")
        return resultado
    }


    fun evaluarExpresion(expresion: String): Double {
        try {
            val parser = ExpressionParser(this)
            val resultado = parser.evaluar(expresion.trim())
            registrarOperacion("Expresión '$expresion' = $resultado")
            return resultado
        } catch (e: Exception) {
            throw ExpresionInvalidaException("Error al evaluar '$expresion': ${e.message}")
        }
    }
}
